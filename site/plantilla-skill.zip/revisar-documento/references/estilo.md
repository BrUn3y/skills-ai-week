# Criterios de estilo

- Usa frases claras y verbos concretos.
- Conserva nombres, cifras y la intención del autor.
- Distingue errores de preferencias editoriales.
